# Copyright (c) OpenMMLab. All rights reserved.
from .output import OutputHook

__all__ = ['OutputHook']
